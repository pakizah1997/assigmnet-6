//.............................CHAPTER 21-25...............................
//1. Write a program that takes two user inputs for first and last name using prompt and merge them in a new variable titled fullName. Greet the user using his full name.
var fname = prompt("Enter First name: ");
var lname = prompt("Enter last name: ");
var fullname = fname + lname;
alert("Welcome " + fullname);

//2. Write a program to take a user input about his favorite mobile phone model. Find and display the length of user input in your browser
var input = prompt("Enter your Favourite Mobile Phone Model: ");
var length = input.length;
document.write("My Favourite Mobile Phone is: " + input);
document.write("Length Of String :" + length);

//3. Write a program to find the index of letter “n” in the word “Pakistani” and display the result in your browser .
var str = "Pakistani";
var n = str.indexOf("n");
document.write("String: " + str);
document.write("Index of 'n': " + n);

//4. Write a program to find the last index of letter “l” in the word “Hello World” and display the result in your browser.
var str = "Hello World";
var n = str.lastindexOf("l");
document.write("String: " + str);
document.write("Index of 'n': " + n);

//5. Write a program to find the character at 3rd index in the word “Pakistani” and display the result in your browser.
var str = "Pakistani";
var thirdchar = str.charAt(3);
document.write("String: " + str);
document.write("Character at index 3: " + thirdchar);

//6. Repeat Q1 using string concat() method.
var str = "Pakistani";
var str1 = str.slice(0, 3);
var str2 = str.charAt(3);
var str3 = str.slice(3);
var res = str1.concat(str2, str3);
document.write(res);

//7. Write a program to replace the “Hyder” to “Islam” in the word “Hyderabad” and display the result in your browser.
var text = "Hyderabad";
document.write("City: " + text);
for (var i = 0; i < text.length; i++) {
    if (text.slice(i, i + 12) === "Hyder") {
        text = text.slice(0, 1) + "Islam" + text.slice(i + 12);
    }
}
document.write("After Replacemewnt: " + text);

//8. Write a program to replace all occurrences of “and” in the string with “&” and display the result in your browser. 
//var message = “Ali and Sami are best friends. They play cricket and football together.”;
var message = "Ali and Sami are best friends. They play cricket and football together.";
document.write("Message: " + message);
var newMessage = message.replace(/and/g, "&");
document.write("Message after replacement: " + newMessage);

//9. Write a program that converts a string “472” to a number 472. Display the values & types in your browser.
var value = "472";
document.write("Value: " + value);
var result = typeof value;
document.write("Type: " + result);
var value1 = parseInt(value);
document.write("Value: " + value1);
var result1 = typeof value1;
document.write("Type: " + result1);

//10. Write a program that takes user input. Convert and show the input in capital letters.
var str = prompt("Input a String: ");
document.write(str);
str = str.toUpperCase();
document.write(str);

//11. Write a program that takes user input. Convert and show the input in title case.
var text = prompt("Enter some text");
document.write("Users input : " + text)
var captializeStrig = (str) => str[0].toUpperCase() + str.slice(1).toLowerCase();
var res = text.split(' ').map(captializeStrig);
var capitalizeSentence = res.join(' ');
document.write("<br>Upper case : " + capitalizeSentence)

//12. Write a program that converts the variable num to string. var num = 35.
var num = 35.36;
document.write("Number: " + num);
num = num.toString();
num = num.replace('.', '');
document.write("Result: " + num);

//13. Write a program to take user input and store username in a variable. If the username contains any special symbol among [@ . , !], prompt the user to enter a valid username. For character codes of [@ .
//Note: ASCII code of ! is 33 
//ASCII code of , is 44 
//ASCII code of . is 46 
//ASCII code of @ is 64




//14. You have an array A = [cake”, “apple pie”, “cookie”, “chips”, “patties”] Write a program to enable “search by user input” in an array. After searching, prompt the user whether the given item is found in the list or not. Note: Perform case insensitive search. Whether the user enters cookie, Cookie, COOKIE or coOkIE, program should inform about its availability.
var item = prompt("Welcome to ABC bakery. What do you want to order sir/ma'am ?: ");
var arr = ["cake", "apple pie", "cookie", "chips", "patties"]
for (var i = 0; i < arr.length; i++) {
    if (arr(i) === item) {
        var index = arr.indexOf(i);
        document.write(item + "is present at index " + index + "in our bakery");
    } else {
        document.write("We are sorr." + item + "is not available in our bakery");
    }
}

//15. Write a program to take password as an input from user. The password must qualify these requirements: a. It should contain alphabets and numbers b. It should not start with a number c. It must at least 6 characters long If the password does not meet above requirements, prompt the user to enter a valid password. For character codes of a-z, A-Z & 0-9, refer to ASCII table at the end of this document.
// Declare variables and constants
var username;           // username entered by user
var charAny;            // text character identified in username
var anyNum = false;     // digit variable used to detect whether the username has one or not
var index;              // index loop variable
var BR = "<br />";      //break
var ES = "";            //space

// Display program requirements for the username requested
document.write("We'll begin helping you select a username" + BR);
document.write("Your username must have at least 8 characters," + BR);
document.write("   start with a letter, and contain at least 1 numeric character." + BR);
username = prompt("Please enter your username: ", ES);

// Check for length of username
while (username.length < 8) {
    document.write("Your username must be at least 8 characters long." + BR);
    username = prompt("Please enter your username: ", ES);
}

// Check that first character is a letter
// Substring function has three arguments: string, starting position, and ending position
charAny = username.substr(0, 1);
while (charAny !== isLetter()) {
    document.write("The first character of your username must be a letter." + BR);
    username = prompt("Please enter your username: ", ES);
}

// Check that there's at least one digit in the username
while (anyNum !== false) {
    // Check each character, set anyNum to true if a digit
    for (index = 1; index < username.substr(index, index); index++) {
        anyNum = username.substr(index, index);
        if (isNumeric(charAny)) {
            anyNum = true;
        }
    }

    // If anyNum is false there were no numerics
    if (anyNum !== true) {
        document.write("Your username must include at least 1 digit." + BR);
        username = prompt("Please enter your username: ", ES);
    }
}

// Thank the user and end the program
document.write("Thank you! Your new username is: " + username);

//16. Write a program to convert the following string to an array using string split method. var university = “University of Karachi”; Display the elements of array in your browser.
var str = "University of Karachi";
var array = str.split('');
document.write(array + BR)

//17. Write a program to display the last character of a user input.
var str = prompt("User input: ");
str= str.charAt(-1)
document.write("Last character of input is: " + str)

//18. You have a string “The quick brown fox jumps over the lazy dog”. Write a program to count number of occurrences of word “the” in given string.

var str="You have a string “The quick brown fox jumps over the lazy dog";
document.write("Text : " +str)
var count = (str.match(/The/g) || []).length;
var count1= (str.match(/The/g) || []).length;
count2=count+count1;
document.write("<br>There are "+count2 +"occurrences of word “the”")
//.............................CHAPTER 26-30...............................
//...................QUESTION 1....
//1. Write a program that takes a positive integer from user & display the following in your browser.
//a. number
//b. round off value of the number
//c. floor value of the number
//d. ceil value of the number

//.........ANSWER
number =+prompt("Enter positive integer:")
if (number<=0){
alert("not a positive number")
}
else{
document.write("number =" +number)
}
var roundOffValue = Math.round(number)
document.write("<br>Round off value = " +roundOffValue)
var floorValue = Math.floor(number)
document.write("<br>Floor value of number =" +floorValue)
var ceilValue =Math.ceil(number)
document.write("<br>Ceil value of number = " +number)

//...................QUESTION 2....
//2. Write a program that takes a negative floating point number from user & display the following in your browser.
//a. number
//b. round off value of the number
//c. floor value of the number
//d. ceil value of the number

//.........ANSWER
var number =+prompt("Enter a negative floating point integer:")
if (number>=0){
alert("not a negative floating point number")
}
else{
document.write("number =" +number)
}
var roundOffValue = Math.round(number)
document.write("<br>Round off value = " +roundOffValue)
var floorValue = Math.floor(number)
document.write("<br>Floor value of number =" +floorValue)
var ceilValue =Math.ceil(number)
document.write("<br>Ceil value of number = " +number)

//...................QUESTION 3....
//3. Write a program that displays the absolute value of a number. E.g. absolute value of -4 is 4 & absolute value of 5 is 5

//.........ANSWER
var num =+prompt("Enter positive or negative number")
var absoluteValue =Math.abs(num)
document.write("Absolute value of" +num +"=" +absoluteValue)

//...................QUESTION 4....
//4. Write a program that simulates a dice using random() method of JS Math class. Display the value of dice in your browser.:

//.........ANSWER
var diceRoll1 = Math.floor( Math.random() * 6 ) +1;
document.write('Random dice value : ' + diceRoll1);
var diceRoll2 = Math.floor( Math.random() * 6 ) +1;
document.write('<br>Random dice value : ' + diceRoll2);

//...................QUESTION 5....
//5. Write a program that simulates a coin toss using random() method of JS Math class. Display the value of coin in your browser

//.........ANSWER
var heads = 0;
var tails = 0;
if (Math.random() < 0.5){
    document.write("2<br> Random coin value:Heads")
}else{
    document.write("1<br> Random coin value: Tails")
}

//...................QUESTION 6....
//6. Write a program that shows a random number between 1 and 100 in your browser.

//.........ANSWER
var number = Math.floor(Math.random() * 100);
document.write("Random number between 1 and 100 : " +number)

//...................QUESTION 7....
//7. Write a program that asks the user about his weight. Parse the user input and display his weight in your browser. Possible user inputs can be:
// a. 50
// b. 50kgs
// c. 50.2kgs
// d. 50.2kilograms

//.........ANSWER
var weight = prompt("Enter your weight in Kilograms")
document.write("The weight of users is "+weight)

//...................QUESTION 8....
//8. Write a program that stores a random secret number from 1 to 10 in a variable. Ask the user to input a number between 1 and 10. If the user input 
//equals the secret number, congratulate the user.

//.........ANSWER
var secretNum=Math.floor(Math.random()*10)
var number =+prompt("Enter a number between 1 and 10")
if (number===secretNum){
    alert("Congratulation you won!")
}
else{
    alert("Try again!")
}
// chp 31-34




//...................QUESTION 1....
var d = new Date()
var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
var days=["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"]

document.write(days[d.getDay()]+" "+months[d.getMonth()]+" "+d.getDate()+" "+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+" GMT+0500 (PKT)")






//...................QUESTION 2 ....
var d = new Date();
var months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

document.write("Current Month: "+months[d.getMonth()])



//...................QUESTION 3....
var d =new Date();
var days=["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"]
document.write("Today is "+days[d.getDay()])





//...................QUESTION 4....
var d =new Date();
if(d.getDay==0||d.getDay==6){

    document.write("It’s Fun day")
}





//...................QUESTION 5....


var d =new Date();
if(d.getDate<=15){

    document.write("First fifteen days of the month")
}else{

    document.write("Last days of the month")
}



//...................QUESTION 6....



var d = new Date()
var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
var days=["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"]

document.write("Current Date: "+days[d.getDay()]+" "+months[d.getMonth()]+" "+d.getDate()+" "+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+" GMT+0500 (PKT)")
document.write("<br>Elapse milliseconds since January 1,1970: "+d.getTime())
document.write("<br>Elapse Minutes since January 1,1970: "+Math.round(d.getTime()/3600))







//...................QUESTION 7....

var d =new Date();
if(d.getHours<=12){

    document.write("Its AM")
}else{

    document.write("Its PM")
}





//...................QUESTION 8....


var d = new Date(2020,11,31)
var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
var days=["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"]

document.write("later Date: "+days[d.getDay()]+" "+months[d.getMonth()]+" "+d.getDate()+" "+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+" GMT+0500 (PKT)")








//...................QUESTION 9....

var month=5
var date=18
var year=2015

var d = new Date(year,month,date)
var d1 =new Date()


var time=d1.getTime()-d.getTime()

var days = (time / (60*60*24*1000))

document.write(Math.floor(days)+" days have passed since 1st Ramadan,2015")



//...................QUESTION 10....






var month=0
var date=1
var year=2015

var d1 = new Date(year,month,date)
var d =new Date()

var time=d.getTime()-d1.getTime()
var second = (time / (60*60))

var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
var days=["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"]

document.write("on refrence date  "+days[d.getDay()]+" "+months[d.getMonth()]+" "+d.getDate()+" "+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+" GMT+0500 (PKT),<br>"+Math.floor(second)+" seconds had passed since the beginning of 2015")













//...................QUESTION 11....

var d =new Date()

var d1 = new Date(d.getFullYear(),d.getMonth(),d.getDate(),d.getHours()-1,d.getMinutes(),d.getSeconds())

var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
var days=["Sun","Mon","Tues","Wed","Thurs","Fri","Sat"]

document.write("Current date : "+days[d.getDay()]+" "+months[d.getMonth()]+" "+d.getDate()+" "+d.getFullYear()+" "+d.getHours()+":"+d.getMinutes()+":"+d.getSeconds()+" GMT+0500 (PKT),<br>1 hour ago, it was "+days[d1.getDay()]+" "+months[d1.getMonth()]+" "+d1.getDate()+" "+d1.getFullYear()+" "+d1.getHours()+":"+d1.getMinutes()+":"+d1.getSeconds()+" GMT+0500 (PKT)")







//...................QUESTION 12....

var age=prompt("Enter Your age")
var ageI = parseInt(age)
var d =new Date()

document.write("Your age is "+age+"<br>Your birth year is "+(d.getFullYear()-ageI))










//...................QUESTION 13....

var d =new Date()

var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]


var name=prompt("Name")
var un=Math.random()*801
var unit=un.toFixed(2)
document.writeln("<h1>K-Electric Bill</h1>")
document.write("Customer Name: "+name+"<br>Month: "+months[d.getMonth()]+"<br>Number of Units: "+unit+"<br>charges per unit: 16<br><br>")
document.write("Net Amount Payable (Within Due Date):"+(16*unit)+"<br>Late payment surcharge: 350<br>Gross Amount Payable (after Due Date): "+(350+(unit*16)))
// chp35-38




//...................QUESTION 11....
function nowdate() {

    var d = new Date()
    var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"]
    var days = ["Sun", "Mon", "Tues", "Wed", "Thurs", "Fri", "Sat"]


    return days[d.getDay()] + " " + months[d.getMonth()] + " " + d.getDate() + " " + d.getFullYear() + " " + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds() + " GMT+0500 (PKT)"

}

document.write(nowdate())





//...................QUESTION 2....



function name(fName,lName){



    return "Welcome "+fName+lName

}

var firstName=prompt("Enter firstname")

var lastName=prompt("Enter lastname")

document.write(name(firstName,lastName))









//...................QUESTION 3....


function add(num1,num2){

    Inum1 = parseInt(num1)
    Inum2 = parseInt(num2)
    return Inum1+Inum2

}

var numb1=prompt("Enter number1")

var numb2=prompt("Enter number2")

document.write(add(numb1,numb2))









//...................QUESTION 4....














function add(num1,num2){

    Inum1 = parseInt(num1)
    Inum2 = parseInt(num2)
    return Inum1+Inum2

}


function sub(num1,num2){

    Inum1 = parseInt(num1)
    Inum2 = parseInt(num2)
    return Inum1-Inum2

}

function mul(num1,num2){

    Inum1 = parseInt(num1)
    Inum2 = parseInt(num2)
    return Inum1*Inum2

}


function div(num1,num2){

    Inum1 = parseInt(num1)
    Inum2 = parseInt(num2)
    return Inum1/Inum2

}


var numb1=prompt("Enter number1")
var op=prompt("Enter Operator")
var numb2=prompt("Enter number2")

if(op=="+"){

    document.write(add(numb1,numb2))
}else if(op=="-"){

    document.write(sub(numb1,numb2))
}else if(op=="*"){

    document.write(mul(numb1,numb2))
}else if(op=="/"){

    document.write(div(numb1,numb2))
}








//...................QUESTION 5....




function sqrt(num1) {

    Inum1 = parseInt(num1)
    return Inum1 * Inum1
}


var numb1 = prompt("Enter number1")


document.write(sqrt(numb1))










//...................QUESTION 6....

function factorial(num){

    if(num<=1){

        return 1
    }
    else{
        temp=num
        var fct=1
        for(i=0;i<num;i++){

            fct=fct*temp
            temp--

        }
        return fct
    }

}

num=prompt("enter num")
numI=parseInt(num)

document.write(factorial(numI))






//...................QUESTION 7....




function count(num1,num2){

    var numb=[] 
    temp=num1
    for(i=0;i<num2-temp;i++){
     numb[i]=num1+1
     num1++
    }
    return numb
}

var start=prompt("Enter start num")
var end=prompt("Enter end num")

startI=parseInt(start)
endI=parseInt(end)

document.writeln(count(startI,endI))










//...................QUESTION 8....


function sq(num1) {

    Inum1 = parseInt(num1)
    return Inum1 * Inum1
}


function hyp(num1,num2){

    return Math.sqrt(sq(num1)+sq(num2))
}



num=prompt("enter base")
numI=parseInt(num)

num1=prompt("enter perp")
num1I=parseInt(num1)


document.write(hyp(numI,num1I))









//...................QUESTION 9....

function rectA(height,width){

     return height*width

}


var height =prompt("Enter Height")
var width=prompt("Enter width ")

document.write(rectA(height,width))








//...................QUESTION 10....


var wordR=""
var ln = prompt("Enter to check palindrome")
var tempWord = ln.split("");


for(i=tempWord.length-1;i>=0;i--){

    wordR=wordR+tempWord[i]

}


if (ln==wordR) {
    document.write("word is a palindrome")
} else {
    document.write("word isn't a palindrome")
}









//...................QUESTION 11....
function small(inp) {


    var inpSmall = inp.toLowerCase()
    var chrCap = inpSmall.charAt(0)
    chrCap = chrCap.toUpperCase()
    var sep = inpSmall.split("")
    sep[0] = chrCap
    inpSmall = sep.join("")
    return inpSmall

}


function Capsent(inp){


var propSent=""
var inpSmall = inp.toLowerCase()
var sp = inpSmall.split(" ")

for(i=0;i<sp.length;i++){


   propSent=propSent+small(sp[i])+" "

}

return propSent
}

var inp = prompt("Enter ")

document.write(Capsent(inp))










//...................QUESTION 12....


function Long(sent) {

    var strSp = sent.split(' ')
    var longestWord = 0


    for(var i = 0; i < strSp.length; i++){

      if(strSp[i].length > longestWord){
      longestWord = strSp[i].length
      num=i
       }
    }


    return strSp[num]
}

var sen =prompt("Enter Sentence")

document.write(Long(sen))











//...................QUESTION 13....
function chec(sent, chr) {

    var strSp = sent.split('');


    num = 0
    for (var i = 0; i < strSp.length; i++) {

        if (strSp[i] == chr) {
            num = num + 1

        }
    }


    return num
}

var sen =prompt("Enter Sentence")
var ch =prompt("Enter character")


document.write(chec(sen,ch))











//...................QUESTION 14....


function calcCircumference(radius){

     
    return "The circumference is"+(2*3.14*radius)

}



function calcCircumference(radius){

     
    return "The area is"+(3.14*radius*radius)

}



